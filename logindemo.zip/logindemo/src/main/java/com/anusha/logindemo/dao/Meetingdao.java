package com.anusha.logindemo.dao;

import org.springframework.data.repository.CrudRepository;

import com.anusha.logindemo.model.Meeting;

public interface Meetingdao  extends CrudRepository<Meeting,Integer> {

}
