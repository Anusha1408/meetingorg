package com.anusha.logindemo.model;

public enum ActiveStat {
       ACTIVE,
       BLOCK,
       CANCEL;
}
