package com.anusha.logindemo.dao;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.anusha.logindemo.model.Login;



@Repository
public interface Logindao extends CrudRepository<Login,String>{
	
}


