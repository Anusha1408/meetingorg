package com.anusha.logindemo.model;

public enum RoleName {
	ADMIN,
	ORGANISER,
	PARTICIPANT
}



