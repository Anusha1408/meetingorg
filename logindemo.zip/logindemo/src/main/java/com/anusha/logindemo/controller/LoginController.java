package com.anusha.logindemo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.anusha.logindemo.dao.Logindao;
import com.anusha.logindemo.model.Login;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping(path="/api")
public class LoginController {
	
	@Autowired
	private Logindao loginRepo;

	// REST API is an Architecture of a Web Service
	// It has Four Major Operation CREATE, GET, PUT, DELETE
	 @PostMapping(path = "verify_user", consumes = {"application/json"})
	    @ResponseBody
	    ResponseEntity<Login> verify_user(@RequestBody Login credentials_object) {

		 Login object = loginRepo.findById(credentials_object.getUserName()).orElse(new Login("","",null,""));
	        if (object.getUserName().equals("")) {
	            return new ResponseEntity<Login>(object, HttpStatus.NOT_FOUND);
	        } else if (!credentials_object.getPassword().equals(object.getPassword())) {
	            return new ResponseEntity<Login>(object, HttpStatus.BAD_REQUEST);
	        } else {
	            return new ResponseEntity<Login>(object, HttpStatus.OK);
	        }

	    }
}
