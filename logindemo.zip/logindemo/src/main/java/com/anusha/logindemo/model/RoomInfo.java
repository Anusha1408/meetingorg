package com.anusha.logindemo.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="roominfo")
public class RoomInfo {
	
	@Id
	@Column(name="roomno")
	private int roomNumber;
	
	@Column(name="roomname")
	private String roomName;
	
	@Column(name="description")
	private String description;

	
	 public RoomInfo() 
	 {
		 
	 }
	
	 

	public int getRoomNumber() {
		return roomNumber;
	}



	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}



	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public RoomInfo(int roomNumber, String roomName, String description) {
		super();
		this.roomNumber = roomNumber;
		this.roomName = roomName;
		this.description = description;
	}
	
	@Override
	public String toString() {
		return "RoomInfo [roomNumber=" + roomNumber + ", roomName=" + roomName + ", description=" + description + "]";
	}
	
	

}
