package com.anusha.logindemo.model;


import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="meeting")
public class Meeting {
	
	@Id
	@Column(name="meetingid")
	private int meetingId;
	
	String username;
	
	@Column(name="meetingdate")
	private String meetingdate;
	
	@Column(name="start_time")
	private String starttime;
	
	@Column(name="end_time")
	private String endtime;
	
	@Column(name="active_status")
	@Enumerated(EnumType.STRING)
	private ActiveStat activestatus;
	
	 @Column(name = "roomno")
	 private int roomno;
	



	public Meeting() {

	}
    
    public Meeting(int meetingId, String username, String meetingdate, String starttime, String endtime, ActiveStat activestatus, int roomno) {
        this.meetingId = meetingId;
        this.username = username;
        this.meetingdate = meetingdate;
        this.starttime = starttime;
        this.endtime = endtime;
        this.activestatus = activestatus;
        this.roomno = roomno;
    }

    public int getMeetingId() {
        return meetingId;
    }

    public void setMeetingId(int meetingId) {
        this.meetingId = meetingId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMeetingdate() {
        return meetingdate;
    }

    public void setMeetingdate(String meetingdate) {
        this.meetingdate = meetingdate;
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public ActiveStat getActivestatus() {
        return activestatus;
    }

    public void setActivestatus(ActiveStat activestatus) {
        this.activestatus = activestatus;
    }

    public int getRoomno() {
        return roomno;
    }

    public void setRoomno(int roomno) {
        this.roomno = roomno;
    }

    @Override
    public String toString() {
        return "meeting{" +
                "meetingId=" + meetingId +
                ", username='" + username + '\'' +
                ", meetingdate='" + meetingdate + '\'' +
                ", starttime='" + starttime + '\'' +
                ", endtime='" + endtime + '\'' +
                ", activestatus=" + activestatus +
                ", roomno=" + roomno +
                '}';
    }
	
	
	

}
