package com.anusha.logindemo.model;



import java.util.Date;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;


@Entity
@Table(name = "logininfo")
public class Login {

	@Id
	@GeneratedValue
	@Column(name = "username")
	private String userName;

	@Column(name = "password")
	private String password;

	@Column(name = "lastlogin")
	private Date lastLogin;
	
	@Column(name="rolename")
	private String rolename;

	/*

	@OneToMany(mappedBy="user", fetch=FetchType.EAGER)
	@JsonBackReference
	private Set<Role> roles = new HashSet<>();*/

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getLastLogin() {
		return lastLogin;
	}

	public void setLastLogin(Date lastLogin) {
		this.lastLogin = lastLogin;
	}
    /*
	public Set<Role> getRoles() {
		return roles;
	}

	public void setRoles(Set<Role> roles) {
		this.roles = roles;
	}
        */
	public Login() {

	}

	public Login(String userName, String password, Date lastLogin,String rolename) {
		super();
		this.userName = userName;
		this.password = password;
		this.lastLogin = lastLogin;
		this.rolename = rolename;
	}

	public String toString() {
		return this.userName;
	}

}
