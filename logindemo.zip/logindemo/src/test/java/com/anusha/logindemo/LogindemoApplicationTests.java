package com.anusha.logindemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogindemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
